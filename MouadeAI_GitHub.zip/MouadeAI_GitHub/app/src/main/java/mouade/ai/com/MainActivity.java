package mouade.ai.com;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String API = "https://ahmaedinfo.serv00.net/api/deepseek.php";
    private static final String SYSTEM = "انت Mouade AI مساعد ذكي صنعه معاذ جلال من الجزائر. تكلم بالعربية الجزائرية. كن مختصرا ومفيدا.";

    private LinearLayout chatContainer;
    private ScrollView scrollView;
    private EditText etInput;
    private Button btnSend, btnClear;
    private TextView tvTyping;
    private final List<Map<String,String>> ctx = new ArrayList<>();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chatContainer = findViewById(R.id.chatContainer);
        scrollView    = findViewById(R.id.scrollView);
        etInput       = findViewById(R.id.etInput);
        btnSend       = findViewById(R.id.btnSend);
        btnClear      = findViewById(R.id.btnClear);
        tvTyping      = findViewById(R.id.tvTyping);

        addMsg("Mouade AI", "اهلا! انا Mouade AI صنعني معاذ جلال من الجزائر. كيفاش نعاونك؟", false);

        btnSend.setOnClickListener(v -> send());
        btnClear.setOnClickListener(v -> {
            ctx.clear();
            chatContainer.removeAllViews();
            addMsg("Mouade AI", "تم المسح! ابدا محادثة جديدة", false);
        });
    }

    private void send() {
        String txt = etInput.getText().toString().trim();
        if (txt.isEmpty()) return;
        etInput.setText("");
        addMsg("انت", txt, true);
        tvTyping.setVisibility(View.VISIBLE);
        btnSend.setEnabled(false);
        exec.execute(() -> {
            String reply = callAPI(txt);
            handler.post(() -> {
                tvTyping.setVisibility(View.GONE);
                btnSend.setEnabled(true);
                if (reply != null && !reply.isEmpty()) {
                    Map<String,String> u = new HashMap<>(); u.put("role","user"); u.put("content",txt); ctx.add(u);
                    Map<String,String> a = new HashMap<>(); a.put("role","assistant"); a.put("content",reply); ctx.add(a);
                    if (ctx.size() > 20) ctx.subList(0,2).clear();
                    addMsg("Mouade AI", reply, false);
                } else {
                    addMsg("Mouade AI", "خطأ في الاتصال! تحقق من الانترنت", false);
                }
            });
        });
    }

    private String callAPI(String input) {
        try {
            StringBuilder prompt = new StringBuilder(SYSTEM + "\n\n");
            for (Map<String,String> m : ctx) {
                prompt.append(m.get("role").equals("user") ? "المستخدم" : "AI")
                      .append(": ").append(m.get("content")).append("\n");
            }
            prompt.append("\nالمستخدم: ").append(input);
            URL url = new URL(API + "?message=" + URLEncoder.encode(prompt.toString(),"UTF-8") + "&model=DeepSeek-V3");
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(30000); c.setReadTimeout(60000);
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("data:")) {
                    String chunk = line.substring(5).trim();
                    if (chunk.equals("[DONE]")) break;
                    try { JSONObject j = new JSONObject(chunk); if(j.has("content")) sb.append(j.getString("content")); }
                    catch(Exception ignored){}
                }
            }
            r.close(); c.disconnect();
            return sb.toString().trim();
        } catch (Exception e) { return null; }
    }

    private void addMsg(String sender, String text, boolean isUser) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(12,8,12,8);
        row.setGravity(isUser ? Gravity.END : Gravity.START);
        TextView name = new TextView(this);
        name.setText(sender + " - " + fmt.format(new Date()));
        name.setTextColor(Color.parseColor(isUser ? "#4488FF" : "#00CFFF"));
        name.setTextSize(11);
        name.setGravity(isUser ? Gravity.END : Gravity.START);
        TextView msg = new TextView(this);
        msg.setText(text);
        msg.setTextColor(Color.parseColor("#EEEEFF"));
        msg.setTextSize(15);
        msg.setPadding(24,16,24,16);
        msg.setBackgroundColor(Color.parseColor(isUser ? "#1A2A4A" : "#0D1A2E"));
        row.addView(name);
        row.addView(msg);
        chatContainer.addView(row);
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }
}
